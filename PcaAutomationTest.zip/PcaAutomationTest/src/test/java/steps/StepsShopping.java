package steps;

import pages.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsShopping {

	private PageLogin pageLogin;
	private PageMyStore pageMyStore;
	private WebDriver driver;
	private String url;
	
	@Given("The user accesses the application")
	public void theUserAccessesTheApplication() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\micarlla.a.melo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		url = "http://automationpractice.com/index.php";
		driver.manage().window().maximize();
		
		pageLogin = new PageLogin(url, driver);
		pageLogin.openUrl();
	}

	@When("The user clicks on Sign in button")
	public void theUserClicksOnSignInButton() {
		pageLogin.openLoginPage();
	}

	@When("The user inputs the email {string}")
	public void theUserInputsTheEmail(String string) {
		pageLogin.getEmail(string);
	}

	@When("The user inputs the password {string}")
	public void theUserInputsThePassword(String string) {
		pageLogin.getPassword(string);
	}
	
	@When("The user clicks on Sign in button to submit login")
	public void theUserClicksOnSignInButtonToSubmitLogin() {
		pageLogin.submitLogin();
	}

	@Then("The My Account page is shown")
	public void theMyAccountPageIsShown() {
		pageLogin.isMyAccountPage();
	}
	
	@Given("The page My Store is shown")
	public void thePageMyStoreIsShown() {
		pageMyStore = new PageMyStore(url, driver);
		pageMyStore.goPageMyStore();
	}
	
	@Given("The user clicks on product")
	public void theUserClicksOnProduct() {
	    pageMyStore.selectProduct();
	}

	@When("The page with the product is shown")
	public void thePageWithTheProductIsShown() {
	    pageMyStore.productSelectedPage();
	}

	@When("The user clicks on Add to cart button")
	public void theUserClicksOnAddToCartButton() {
	    pageMyStore.addToCart();
	}

	@Then("The product is added to cart")
	public void theProductIsAddedToCart() {
	    pageMyStore.validateProductAddToCart();
	}

	@Then("The user clicks on Close button")
	public void theUserClicksOnCloseButton() {
	    pageMyStore.closeShopping();
	}
	
	@Given("The user puts the mouse on product")
	public void theUserPutsTheMouseOnProduct() {
	    
	}

	@When("The user clicks Quick view button")
	public void theUserClicksQuickViewButton() {
	    
	}

	@Then("A modal window is opened")
	public void aModalWindowIsOpened() {
		
	}

}
