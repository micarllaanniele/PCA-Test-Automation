package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ById;
import org.openqa.selenium.WebDriver;

import junit.framework.Assert;

public class PageLogin extends PageBase {
	
	private String text;
	
	//Elements locators
	private By signButton = By.cssSelector("div.header_user_info");
	private By emailAddress = By.id("email");
	private By password = By.id("passwd");
	private By submitLoginButton = By.id("SubmitLogin");
	private By isMyAccountPage = By.cssSelector("h1.page-heading");
	
	
	public PageLogin(String url, WebDriver driver) {
		super(url, driver);
	}
		
	public void openLoginPage() {
		driver.findElement(this.signButton).click();
	}
	
	public void getEmail(String email) {
		driver.findElement(this.emailAddress).sendKeys(email);
	}
	
	public void getPassword(String passwd) {
		driver.findElement(this.password).sendKeys(passwd);
	}
	
	public void submitLogin() {
		driver.findElement(this.submitLoginButton).click();
	}
	
	public void isMyAccountPage() {
		try {
			text = driver.findElement(this.isMyAccountPage).getText();
			Assert.assertEquals("MY ACCOUNT", text);
		} catch (Exception e) {
			System.out.println("My Account's page not found!");
		}
	}
}
