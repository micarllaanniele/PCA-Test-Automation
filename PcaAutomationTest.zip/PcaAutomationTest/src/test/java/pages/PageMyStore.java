package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import junit.framework.Assert;

public class PageMyStore extends PageBase {

	//Elements locators
	private By isMyStorePage = By.id("homepage-slider");
	private By myStore = By.className("home");
	private By product = By.cssSelector(".product_list li:nth-of-type(1) .product-container");
	private By addToCartButton = By.name("Submit");
	private By productIsAdd = By.cssSelector(".icon-ok");
	private By closeButton = By.className("cross");
	
	public PageMyStore(String url, WebDriver driver) {
		super(url, driver);
	}
	
	public void goPageMyStore() {
		driver.findElement(this.myStore).click();
		try {
			if(driver.findElement(this.isMyStorePage).isDisplayed()) {
			}	
		} catch (Exception e) {
			System.out.println("My Store's page not found!");
		}
	}
	
	public void selectProduct() {
		driver.findElement(product).click();
	}
	
	public void productSelectedPage() {
		try {
			if(driver.findElement(this.addToCartButton).isDisplayed()) {
			}	
		} catch (Exception e) {
			System.out.println("My Product's page not found!");
		}
	}
	
	public void addToCart() {
		driver.findElement(this.addToCartButton).click();
	}
	
	public void validateProductAddToCart() {
		try {
			if(driver.findElement(this.productIsAdd).isDisplayed()) {
			}
		} catch (Exception e) {
			System.out.println("Error. The product was not included on your cart!");
		}
	}
	
	public void closeShopping() {
		WebDriverWait wait = new WebDriverWait(driver,2);
		WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(this.closeButton));
		driver.findElement(this.closeButton).click();
	}
}
