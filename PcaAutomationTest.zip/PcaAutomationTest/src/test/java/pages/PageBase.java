package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PageBase {
	
	protected WebDriver driver;
	protected String url;
	
	public PageBase(String url, WebDriver driver) {
		this.url = url;
		this.driver = driver;
	}
	
	public void openUrl() {
		driver.get(this.url);
	}
	
	public void quitUrl() {
		driver.quit();
	}
}
