package tasksMain;
import steps.StepsCreateTask;

public class MainScenarioAccessMyTasks {
	//please disregard, only for my tests
	public static void main(String[] args) {
		StepsCreateTask taskSteps = new StepsCreateTask();
		
		taskSteps.theUserAccessesTheApplication();
		String email = "micarlla.anniele@gmail.com";
		taskSteps.theUserInputsTheEmail(email);
		String password = "Micarlla123";
		taskSteps.theUserInputsThePassword(password);
		taskSteps.theUserClicksOnSignInButton();
		taskSteps.theInitialPageIsShown();
		taskSteps.theUserClicksOnMyTasksLinkInNavBar();
		String nameUser = "Micarlla Melo";
		taskSteps.myTasksAreShownOnTheResultPageWithNameUser(nameUser);		
		
	}

}
