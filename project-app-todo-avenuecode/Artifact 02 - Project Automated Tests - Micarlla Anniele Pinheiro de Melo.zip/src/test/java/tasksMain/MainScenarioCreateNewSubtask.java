package tasksMain;

import steps.StepsCreateSubtask;
import steps.StepsCreateTask;

public class MainScenarioCreateNewSubtask {
//please disregard, only for my tests
	public static void main(String[] args) {
		StepsCreateTask taskSteps = new StepsCreateTask();
		StepsCreateSubtask subtask = new StepsCreateSubtask();
		
		taskSteps.theUserAccessesTheApplication();
		String email = "micarlla.anniele@gmail.com";
		taskSteps.theUserInputsTheEmail(email);
		String password = "Micarlla123";
		taskSteps.theUserInputsThePassword(password);
		taskSteps.theUserClicksOnSignInButton();
		taskSteps.theInitialPageIsShown();
		taskSteps.theUserClicksOnMyTasksLinkInNavBar();
		
		subtask.theUserConsultATask("Teste OK");
	}

}
