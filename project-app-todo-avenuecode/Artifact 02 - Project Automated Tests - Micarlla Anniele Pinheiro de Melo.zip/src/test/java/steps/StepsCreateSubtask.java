package steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import scenarios.ScenarioAccessMyTasks;
import scenarios.ScenarioCreateNewSubtask;

public class StepsCreateSubtask {

	private String url;
	private WebDriver driver;
	private ScenarioAccessMyTasks userAccess;
	private ScenarioCreateNewSubtask newSubtask;
	
	public StepsCreateSubtask() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\micarlla.a.melo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		url = "https://qa-test.avenuecode.com/";
		userAccess = new ScenarioAccessMyTasks(driver, url);
		newSubtask = new ScenarioCreateNewSubtask(driver, url);
	}

	@Given("The user accesses the application")
	public void theUserAccessesTheApplication() {

	}

	@Given("The user inputs the email {string}")
	public void theUserInputsTheEmail(String string) {

	}

	@Given("The user inputs the password {string}")
	public void theUserInputsThePassword(String string) {

	}

	@Given("The user clicks on Sign in button")
	public void theUserClicksOnSignInButton() {

	}

	@Given("The initial page is shown")
	public void theInitialPageIsShown() {

	}

	@When("The user clicks on My Tasks link in NavBar")
	public void theUserClicksOnMyTasksLinkInNavBar() {

	}

	@When("The user consult a task {string}")
	public void theUserConsultATask(String string) {

	}

	@When("The user click on Manage Subtask")
	public void theUserClickOnManageSubtask() {

	}

	@When("A dialog modal is opened")
	public void aDialogModalIsOpened() {

	}

	@Then("The user input a subtask description {string}")
	public void theUserInputASubtaskDescription(String string) {

	}

	@Then("The user input subtask due date {string}")
	public void theUserInputSubtaskDueDate(String string) {

	}

	@Then("The user press Close button")
	public void theUserPressCloseButton() {

	}

	@Then("Validate return to task's page")
	public void validateReturnToTaskSPage() {

	}
}
