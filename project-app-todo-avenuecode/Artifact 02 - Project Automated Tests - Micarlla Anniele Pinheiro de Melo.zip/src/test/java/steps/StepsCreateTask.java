package steps;
import scenarios.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsCreateTask {
	
	private String url;
	private WebDriver driver;
	private ScenarioAccessMyTasks userAccess;
	private ScenarioCreateNewTask newTask;
	
	public StepsCreateTask() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\micarlla.a.melo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		url = "https://qa-test.avenuecode.com/";
		userAccess = new ScenarioAccessMyTasks(driver, url);
		newTask = new ScenarioCreateNewTask(driver, url);
	}
	
	@Given("The user accesses the application")
	public void theUserAccessesTheApplication() {
		userAccess.AccessApplication();
	}

	@When("The user inputs the email {string}")
	public void theUserInputsTheEmail(String string) {
		userAccess.getEmail(string);
	}

	@When("The user inputs the password {string}")
	public void theUserInputsThePassword(String string) {
		userAccess.getPassword(string);
	}

	@When("The user clicks on Sign in button")
	public void theUserClicksOnSignInButton() {
		userAccess.login();
	}

	@Then("The initial page is shown")
	public void theInitialPageIsShown() {
		userAccess.openInitialPage();
	}

	@When("The user clicks on My Tasks link in NavBar")
	public void theUserClicksOnMyTasksLinkInNavBar() {
		userAccess.openMyTasks();
	}

	@Then("My tasks are shown on the result page with name user {string}")
	public void myTasksAreShownOnTheResultPageWithNameUser(String string) {
		userAccess.validateMyTasksPageWithNameUser(string);
	}

	@When("The user inputs new task {string}")
	public void theUserInputsNewTask(String string) {
		newTask.inputNewTask(string);
	}

	@When("The user press the add new task button")
	public void theUserPressTheAddNewTaskButton() {
		newTask.PressAddNewTaskButton();
	}

	@Then("The user consult the new task created {string}")
	public void theUserConsultTheNewTaskCreated(String string) {
		newTask.consultNewTaskCreated(string);
	}

}
