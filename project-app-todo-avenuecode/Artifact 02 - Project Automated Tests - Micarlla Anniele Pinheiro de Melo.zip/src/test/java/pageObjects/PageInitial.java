package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import junit.framework.Assert;

public class PageInitial extends PageBase{
	
	public PageInitial(WebDriver driver, String url) {
		super(driver, url);
	}
	
	public void validatePageInitial() {
		try {
			String text = driver.findElement(By.cssSelector("div h1")).getText();
			Assert.assertEquals("ToDo App", text);
		} catch (Exception e) {
			System.out.println("Initial's page not found!");
		}
		
	}
	
	public PageMyTasks openMyTasks() {
		driver.findElement(By.className("nav navbar-nav").linkText("My Tasks")).click();
		return new PageMyTasks(driver, url);
	}
}
