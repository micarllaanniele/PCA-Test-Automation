package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PageBase {
	
	protected WebDriver driver;
	protected String url;
	
	public PageBase(WebDriver driver, String url) {
		this.driver = driver;
		this.url = url;
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	
	public void openUrl() {
		driver.get(this.url);
	}
	
	public PageLogin openLogin() {
		driver.findElement(By.linkText("Sign In")).click();
		return new PageLogin(driver, url);
	}
}
