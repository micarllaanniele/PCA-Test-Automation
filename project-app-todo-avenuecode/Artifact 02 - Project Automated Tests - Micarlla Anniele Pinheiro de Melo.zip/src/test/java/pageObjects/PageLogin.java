package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PageLogin extends PageBase {
	
	public PageLogin(WebDriver driver, String url) {
		super(driver, url);
	}
	
	public void inputLogin(String user, String password) {
		driver.findElement(By.id("user_email")).sendKeys(user);
		driver.findElement(By.id("user_password")).sendKeys(password);
		driver.findElement(By.name("commit")).click();
	}
	
	public PageInitial login(String user, String password) {
		inputLogin(user, password);
		return new PageInitial(driver, url);
	}
	

}
