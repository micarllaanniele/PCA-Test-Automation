package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import junit.framework.Assert;

public class PageMyTasks extends PageBase{
	
	public PageMyTasks(WebDriver driver, String url) {
		super(driver, url);
	}
	
	public void validatePageMyTasks() {
		try {
			String text = driver.findElement(By.className("panel-heading")).getText();
			Assert.assertEquals("To be Done", text);
		} catch (Exception e) {
			System.out.println("My Tasks's page not found!");
		}
	}
	
	public void setTask(String taskName) {
		driver.findElement(By.id("new_task")).sendKeys(taskName);
	}
	
	public void clickAddTask() {
		driver.findElement(By.cssSelector("[ng-click=\"addTask()\"]")).click();
	}
	
	public Integer consultTask(String taskName) {
		String text = driver.findElement(By.cssSelector("[editable-text=\"task.body\"]")).getText();
		return text.indexOf(taskName);
	}
}
