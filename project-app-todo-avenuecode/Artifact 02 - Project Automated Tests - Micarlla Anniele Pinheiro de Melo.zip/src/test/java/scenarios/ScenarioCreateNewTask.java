package scenarios;

import org.openqa.selenium.WebDriver;

public class ScenarioCreateNewTask extends ScenarioAccessMyTasks {
	
	public ScenarioCreateNewTask(WebDriver driver, String url) {
		super(driver, url);
	}
	
	public void inputNewTask(String taskName) {
		this.pageMyTasks.setTask(taskName);
	}
	
	public void PressAddNewTaskButton() {
		this.pageMyTasks.clickAddTask();
	}
	
	public String consultNewTaskCreated(String taskName) {
		if (this.pageMyTasks.consultTask(taskName) < 0) {
			System.out.println("Task name "+taskName+" not found!");
			return taskName;
		}
		else return "Not found";
		
	}
	
}
