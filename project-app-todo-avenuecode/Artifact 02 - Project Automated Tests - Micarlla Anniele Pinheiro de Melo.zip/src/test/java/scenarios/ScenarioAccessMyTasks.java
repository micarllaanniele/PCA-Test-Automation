package scenarios;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import pageObjects.*;
import java.lang.String;

public class ScenarioAccessMyTasks {
	
	protected WebDriver driver;
	protected String url;
	protected String email;
	protected String password;
	protected PageBase pageBase;
	protected PageLogin pageLogin;
	protected PageInitial pageInitial;
	protected PageMyTasks pageMyTasks;
	
	public ScenarioAccessMyTasks(WebDriver driver, String url) {
		this.driver = driver;
		this.url = url;
		this.pageBase = new PageBase(driver, this.url);
		this.pageLogin = new PageLogin(driver, this.url);
		this.pageInitial = new PageInitial(driver, this.url);
		this.pageMyTasks = new PageMyTasks(driver, this.url);
	}
	
	public void AccessApplication() {
		pageBase.openUrl();
	}
	
	public void getEmail(String email) {
		this.email = email;
	}
	
	public void getPassword(String password) {
		this.password = password;
	}
	
	public void login() {
		pageLogin = pageBase.openLogin();
		pageInitial = pageLogin.login(email, password);
	}
	
	public void openInitialPage() {
		pageInitial.validatePageInitial();
	}
	
	public void openMyTasks() {
		pageMyTasks = pageInitial.openMyTasks();
	}
	
	public void validateMyTasksPageWithNameUser(String nameUser) {
		pageMyTasks.validatePageMyTasks();
		validateNameUser(nameUser);
	}
	
	public void validateNameUser(String name) {
		String text = driver.findElement(By.cssSelector("div h1")).getText();
		if (text.indexOf(name) < 0)
			System.out.println("User's name was not found!");
	}
}
