package scenarios;

import org.openqa.selenium.WebDriver;

import pageObjects.PageMyTasks;

public class ScenarioCreateNewSubtask {

	private PageMyTasks pageMyTasks;
	
	public ScenarioCreateNewSubtask(WebDriver driver, String url) {
		pageMyTasks = new PageMyTasks(driver, url);
	}
	
	public String consultTask(String string) {
		if (this.pageMyTasks.consultTask(string) < 0) {
			System.out.println("Task name "+string+" not found!");
			return string;
		}
		else return "Not found";
	}
}
